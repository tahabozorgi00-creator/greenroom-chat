import React, { useEffect, useRef, useState } from 'react';
import { supabase, isConfigured } from './supabase';
import { Gamepad2, Hash, LogOut, Plus, Send, Users, MessageCircle, ShieldCheck, Copy, Leaf } from 'lucide-react';

function makeCode() {
  return Math.random().toString(36).slice(2, 8).toUpperCase();
}
function initials(value = '?') {
  return value.trim().slice(0, 2).toUpperCase();
}

export default function App() {
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nickname, setNickname] = useState('');
  const [isSignup, setIsSignup] = useState(false);
  const [roomCode, setRoomCode] = useState('');
  const [room, setRoom] = useState(null);
  const [rooms, setRooms] = useState([]);
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session) loadRooms();
    else { setRooms([]); setRoom(null); setMessages([]); }
  }, [session]);

  useEffect(() => {
    if (!session || !room) return;
    loadMessages(room.id);
    const channel = supabase.channel(`room-${room.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `room_id=eq.${room.id}` },
        payload => setMessages(old => old.some(m => m.id === payload.new.id) ? old : [...old, payload.new]))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [session, room?.id]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  async function authenticate(e) {
    e.preventDefault(); setBusy(true); setNotice('');
    try {
      if (isSignup) {
        const { error } = await supabase.auth.signUp({
          email, password, options: { data: { nickname: nickname.trim() || email.split('@')[0] } }
        });
        if (error) throw error;
        setNotice('Account created. If email confirmation is enabled, check your inbox before signing in.');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err) { setNotice(err.message || 'Something went wrong.'); }
    finally { setBusy(false); }
  }

  async function loadRooms() {
    const { data, error } = await supabase.from('room_members')
      .select('room_id, rooms(id, name, code, created_at)')
      .eq('user_id', session.user.id);
    if (error) { setNotice(error.message); return; }
    setRooms((data || []).map(x => x.rooms).filter(Boolean));
    if (!room && data?.length) setRoom(data[0].rooms);
  }

  async function loadMessages(roomId) {
    const { data, error } = await supabase.from('messages').select('*')
      .eq('room_id', roomId).order('created_at', { ascending: true }).limit(100);
    if (error) setNotice(error.message);
    else setMessages(data || []);
  }

  async function createRoom() {
    const name = prompt('Give your chat room a name:');
    if (!name?.trim()) return;
    setBusy(true); setNotice('');
    try {
      const code = makeCode();
      const { data: newRoom, error } = await supabase.from('rooms')
        .insert({ name: name.trim().slice(0, 40), code, created_by: session.user.id })
        .select().single();
      if (error) throw error;
      const { error: memberError } = await supabase.from('room_members')
        .insert({ room_id: newRoom.id, user_id: session.user.id });
      if (memberError) throw memberError;
      setRoom(newRoom); setMessages([]);
      await loadRooms();
      setNotice(`Room created! Share invite code ${code} with your friends.`);
    } catch (err) { setNotice(err.message); }
    finally { setBusy(false); }
  }

  async function joinRoom(e) {
    e.preventDefault();
    if (!roomCode.trim()) return;
    setBusy(true); setNotice('');
    try {
      const { data: found, error } = await supabase.rpc('join_room_by_code', {
        invite_code: roomCode.trim().toUpperCase()
      });
      if (error || !found) throw new Error('Room not found. Check the invite code.');
      setRoom(found); setMessages([]); setRoomCode('');
      await loadRooms();
      setNotice(`Joined ${found.name}.`);
    } catch (err) { setNotice(err.message); }
    finally { setBusy(false); }
  }

  async function sendMessage(e) {
    e.preventDefault();
    const content = draft.trim();
    if (!content || !room) return;
    setDraft('');
    const { error } = await supabase.from('messages').insert({
      room_id: room.id, user_id: session.user.id,
      sender_name: session.user.user_metadata?.nickname || session.user.email.split('@')[0],
      content: content.slice(0, 2000)
    });
    if (error) { setDraft(content); setNotice(error.message); }
  }

  async function signOut() { await supabase.auth.signOut(); }
  const myName = session?.user?.user_metadata?.nickname || session?.user?.email?.split('@')[0] || 'Player';

  if (!isConfigured) return <SetupScreen />;
  if (!session) return (
    <main className="auth-wrap">
      <div className="auth-card">
        <div className="brand-mark"><Leaf size={25}/></div>
        <p className="eyebrow">YOUR SQUAD. YOUR SPACE.</p>
        <h1>Green<span>Room</span></h1>
        <p className="muted">A private place to chat with your friends.</p>
        <form onSubmit={authenticate} className="auth-form">
          {isSignup && <label>Nickname<input value={nickname} onChange={e=>setNickname(e.target.value)} placeholder="How friends see you" maxLength="24" /></label>}
          <label>Email<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" /></label>
          <label>Password<input type="password" required minLength="6" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters" /></label>
          <button className="primary full" disabled={busy}>{busy ? 'Please wait…' : isSignup ? 'Create account' : 'Sign in'}</button>
        </form>
        <button className="text-button" onClick={()=>{setIsSignup(!isSignup);setNotice('');}}>
          {isSignup ? 'Already have an account? Sign in' : 'New here? Create an account'}
        </button>
        {notice && <p className="notice">{notice}</p>}
        <p className="tiny"><ShieldCheck size={13}/> Use a password you don't use on other sites.</p>
      </div>
    </main>
  );

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark small"><Leaf size={19}/></div><span>Green<span>Room</span></span></div>
        <div className="side-label">YOUR SPACES</div>
        <div className="room-list">
          {rooms.map(r=><button key={r.id} className={`room-link ${room?.id===r.id?'active':''}`} onClick={()=>setRoom(r)}><Hash size={16}/><span>{r.name}</span></button>)}
          {!rooms.length && <p className="empty-side">No rooms yet. Create one or join a friend.</p>}
        </div>
        <button className="create-room" onClick={createRoom}><Plus size={17}/> Create a room</button>
        <form className="join-form" onSubmit={joinRoom}>
          <label>JOIN WITH INVITE CODE</label>
          <div className="join-row"><input value={roomCode} onChange={e=>setRoomCode(e.target.value)} placeholder="ABC123" maxLength="6"/><button title="Join room" disabled={busy}><Plus size={17}/></button></div>
        </form>
        <div className="profile">
          <div className="avatar">{initials(myName)}</div>
          <div className="profile-name"><strong>{myName}</strong><small>Online</small></div>
          <button className="icon-button" onClick={signOut} title="Sign out"><LogOut size={17}/></button>
        </div>
      </aside>

      <section className="chat-area">
        {room ? <>
          <header className="chat-header">
            <div className="room-title-icon"><Hash size={20}/></div>
            <div><h2>{room.name}</h2><p><span className="green-dot"/> Private room · Share the invite code with friends</p></div>
            <button className="invite-button" onClick={()=>{navigator.clipboard?.writeText(room.code);setNotice(`Invite code ${room.code} copied (if clipboard access is allowed).`);}}><Copy size={15}/> Invite code: {room.code}</button>
          </header>
          {notice && <div className="notice-bar" role="status">{notice}<button onClick={()=>setNotice('')}>×</button></div>}
          <div className="messages">
            {messages.length===0 ? <div className="welcome"><div className="welcome-icon"><MessageCircle size={28}/></div><h2>Welcome to {room.name}</h2><p>This is the beginning of your squad's chat. Share the invite code to bring friends in.</p></div> :
              messages.map(m=><article className={`message ${m.user_id===session.user.id?'mine':''}`} key={m.id}>
                <div className="avatar message-avatar">{initials(m.sender_name)}</div>
                <div className="message-body"><div className="message-meta"><strong>{m.sender_name || 'Player'}</strong><time>{new Date(m.created_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</time></div><p>{m.content}</p></div>
              </article>)}
            <div ref={bottomRef}/>
          </div>
          <form className="composer" onSubmit={sendMessage}>
            <input value={draft} onChange={e=>setDraft(e.target.value)} placeholder={`Message #${room.name}`} maxLength="2000"/>
            <button className="send-button" disabled={!draft.trim()} aria-label="Send message"><Send size={18}/></button>
          </form>
          <p className="composer-hint">Be kind to your squad. Never share passwords or private information.</p>
        </> : <div className="welcome"><div className="welcome-icon"><Users size={28}/></div><h2>Your squad starts here</h2><p>Create a room and share its invite code, or enter a friend's code on the left.</p></div>}
      </section>
    </main>
  );
}

function SetupScreen() {
  return <main className="setup-wrap"><div className="setup-card">
    <div className="brand-mark"><Leaf size={25}/></div><p className="eyebrow">ONE-TIME SETUP</p><h1>Connect <span>GreenRoom</span></h1>
    <p className="muted">The website files are ready. Connect a free Supabase project to enable real accounts and live chat.</p>
    <ol><li>Create a project at <a href="https://supabase.com" target="_blank" rel="noreferrer">Supabase</a>.</li><li>In Project Settings → API, copy the Project URL and anon/public key.</li><li>Copy <code>.env.example</code> to <code>.env</code> and paste both values.</li><li>Run the SQL in <code>supabase/schema.sql</code> using Supabase SQL Editor.</li><li>Run <code>npm install</code> then <code>npm run dev</code>.</li></ol>
    <p className="tiny"><ShieldCheck size={13}/> Never share your Supabase service-role key. The browser only uses the anon/public key.</p>
  </div></main>;
}