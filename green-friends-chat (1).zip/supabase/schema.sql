-- Run this entire file in Supabase → SQL Editor → New query.
-- This MVP uses invite-code rooms. Never expose your service-role key in the website.

create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 40),
  code text not null unique check (char_length(code) = 6),
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.room_members (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

create table if not exists public.messages (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  sender_name text not null check (char_length(sender_name) between 1 and 24),
  content text not null check (char_length(content) between 1 and 2000),
  created_at timestamptz not null default now()
);

create index if not exists messages_room_created_idx
  on public.messages(room_id, created_at);

alter table public.rooms enable row level security;
alter table public.room_members enable row level security;
alter table public.messages enable row level security;

-- Users can see rooms only after joining them.
create policy "members can view their rooms" on public.rooms
for select to authenticated using (
  exists (select 1 from public.room_members rm
          where rm.room_id = rooms.id and rm.user_id = auth.uid())
);
create policy "authenticated users can create rooms" on public.rooms
for insert to authenticated with check (created_by = auth.uid());

create policy "members can view room membership" on public.room_members
for select to authenticated using (
  exists (select 1 from public.room_members mine
          where mine.room_id = room_members.room_id and mine.user_id = auth.uid())
);
create policy "users can join a room" on public.room_members
for insert to authenticated with check (user_id = auth.uid());
create policy "users can leave a room" on public.room_members
for delete to authenticated using (user_id = auth.uid());

create policy "members can read messages" on public.messages
for select to authenticated using (
  exists (select 1 from public.room_members rm
          where rm.room_id = messages.room_id and rm.user_id = auth.uid())
);
create policy "members can send messages as themselves" on public.messages
for insert to authenticated with check (
  user_id = auth.uid()
  and exists (select 1 from public.room_members rm
              where rm.room_id = messages.room_id and rm.user_id = auth.uid())
);

-- Enable live updates for new chat messages.
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
when undefined_object then null;
end $$;

-- Join by invite code without allowing users to list every room.
create or replace function public.join_room_by_code(invite_code text)
returns public.rooms
language plpgsql
security definer
set search_path = public
as $$
declare
  found_room public.rooms;
  current_user_id uuid := auth.uid();
begin
  if current_user_id is null then
    raise exception 'You must be signed in.';
  end if;

  select * into found_room
  from public.rooms
  where code = upper(trim(invite_code));

  if not found then
    return null;
  end if;

  insert into public.room_members(room_id, user_id)
  values (found_room.id, current_user_id)
  on conflict (room_id, user_id) do nothing;

  return found_room;
end;
$$;

revoke all on function public.join_room_by_code(text) from public;
grant execute on function public.join_room_by_code(text) to authenticated;
